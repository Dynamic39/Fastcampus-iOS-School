//
//  SettingsViewController.swift
//  (1022)SettingsTable
//
//  Created by Samuel K on 2017. 10. 22..
//  Copyright © 2017년 Samuel K. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tableView: UITableView!
    
    //구분을 짓는 footer리스트를 어레이로 변환
    var divideSection = ["계정", "정보", "서비스"]
    
    //각 구분별, 섹션 리스트를 별도 정리
    //섹션별 리스트 구성(텍스트 레이블, 이미지)
    var settingsMenu = [["정보수정", "비밀번호 변경", "로그아웃", "회원탈퇴"],["버전정보"],["자동로그인"]]
    var settingsImage = [["info", "pw", "logout", "delacc"],["ver"], ["autoLogin"]]

    //정보에 대한 세부 리스트 정리
    //자동 로그인, 해당셀은 버튼이 포함되어야 함.

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    //전체 세팅할 row의 갯수를 정한다
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //전체 row의 갯수이므로, 섹션별로 구분후, 카운트 하여, 값을 리턴하여 준다.
        return settingsMenu[section].count
        
    }
    
    //섹션의 개수를 구별하여 주는 메서드를 호출한다(아직 안배운것)
    func numberOfSections(in tableView: UITableView) -> Int {
        return divideSection.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? CustomCell
        
        
        //이미지, 레이블 세팅
        cell?.tableImage.image = UIImage(named: "\(settingsImage[indexPath.section][indexPath.row])")
        cell?.tableLabel.text = settingsMenu[indexPath.section][indexPath.row]
        
        return cell!
        
    }
    
    //row의 높이를 조절하는 메서드를 호출한다.
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 70
        
    }
    
    //각 섹션의 타이틀을 설정한다 반환값은 스트링이다.
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return divideSection[section]
        
    }
    
    //하지 못한것
    /*
     
     1. 섹션의 크기, 글자 색상 조절
     2. 특정 셀이 선택 되었을때, 호출되는 뷰 설정
     3. 특정 셀에만 스위치를 설정
     
     */

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
