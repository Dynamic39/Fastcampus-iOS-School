//
//  CustomCell.swift
//  (1022)SettingsTable
//
//  Created by Samuel K on 2017. 10. 22..
//  Copyright © 2017년 Samuel K. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {
    
    @IBOutlet weak var tableLabel: UILabel!
    @IBOutlet weak var tableImage: UIImageView!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
